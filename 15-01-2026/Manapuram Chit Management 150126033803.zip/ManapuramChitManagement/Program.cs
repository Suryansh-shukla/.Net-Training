﻿namespace ManapuramChitManagement //DO NOT change the namespace name
{
    public class Program //DO NOT change the class name
    {
        public static void Main(string[] args)  //DO NOT change the method signature
        {
            //Implement your code here
        }
    }
}
