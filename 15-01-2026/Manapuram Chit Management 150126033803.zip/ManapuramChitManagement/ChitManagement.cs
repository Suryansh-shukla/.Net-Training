﻿namespace ManapuramChitManagement //DO NOT change the namespace name
{
    public class ChitManagement  //DO NOT change the class name
    {
        public static List<Chit> AvailableChit = new List<Chit>()
        {
            new Chit(1001,"Gold-A1",24,260000,"Chennai"),
            new Chit(1002,"Silver-A1",36,420000,"Coimbatore"),
            new Chit(1003,"Platinum-A1",48,750000,"Bangalore"),
            new Chit(1004,"Gold-A2",60,400000,"Chennai"),
            new Chit(1005,"Silver-A2",48,1200000,"Coimbatore")
        };


        //Implement your code here
    }
}
