﻿namespace ManapuramChitManagement //DO NOT change the namespace name
{
    public class Chit //DO NOT change the class name
    {
        //Implement your code here
    }
}
