﻿namespace Beverages
{
    public class BeverageUtility
    {
        // Implement the code here
    }
}