﻿namespace Beverages
{
    public class Beverage
    {
        // Implement the code here
    }
}